package com.musichub.dao;

import com.musichub.model.UserOrder;

public interface OrderDao 
{
	void addOrder(UserOrder userOrder);
}

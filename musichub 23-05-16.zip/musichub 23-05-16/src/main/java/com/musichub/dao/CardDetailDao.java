package com.musichub.dao;

import com.musichub.model.CardDetail;

public interface CardDetailDao 
{
	void addCardDetail (CardDetail cardDetail);
}
